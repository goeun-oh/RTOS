/*
 * Listener_Distance.h
 *
 *  Created on: Jul 4, 2025
 *      Author: kccistc
 */

#ifndef AP_LISTENER_LISTENER_DISTANCE_H_
#define AP_LISTENER_LISTENER_DISTANCE_H_

void Listener_DistanceInit();
void Listener_DistanceExcute();


#endif /* AP_LISTENER_LISTENER_DISTANCE_H_ */
