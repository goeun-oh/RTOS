/*
 * Presenter.h
 *
 *  Created on: Jul 3, 2025
 *      Author: kccistc
 */

#ifndef AP_PRESENTER_PRESENTER_H_
#define AP_PRESENTER_PRESENTER_H_
#include "Presenter_StopWatch.h"
#include "Presenter_TimeWatch.h"
#include "Presenter_Distance.h"
#include "Presenter_TempHumid.h"
#include "Model_Mode.h"
#include "lcd.h"
#include "FND.h"
void Presenter_Init();

void Presenter_Excute();

#endif /* AP_PRESENTER_PRESENTER_H_ */
