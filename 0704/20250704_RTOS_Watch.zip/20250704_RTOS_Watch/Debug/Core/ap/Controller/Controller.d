Core/ap/Controller/Controller.o: ../Core/ap/Controller/Controller.c \
 ../Core/ap/Controller/Controller.h \
 C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_Mode.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h \
 C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_StopWatch.h \
 ../Core/ap/Controller/StopWatch.h ../Core/ap/Controller/TimeWatch.h \
 C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_Watch.h \
 C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Controller/TimeWatch.h \
 ../Core/ap/Controller/Distance.h ../Core/ap/Controller/TempHumid.h
../Core/ap/Controller/Controller.h:
C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_Mode.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS/cmsis_os.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/semphr.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/queue.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/event_groups.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/timers.h:
C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_StopWatch.h:
../Core/ap/Controller/StopWatch.h:
../Core/ap/Controller/TimeWatch.h:
C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Model/Model_Watch.h:
C:/Users/kccistc/STM32/20250704_RTOS_Watch/Core/ap/Controller/TimeWatch.h:
../Core/ap/Controller/Distance.h:
../Core/ap/Controller/TempHumid.h:
