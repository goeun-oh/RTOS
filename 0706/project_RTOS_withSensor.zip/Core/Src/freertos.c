/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * File Name          : freertos.c
 * Description        : Code for freertos applications
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "tim.h"
#include "Listener.h"
#include "Controller.h"
#include "Presenter.h"
#include "Model_Mode.h"
#include "Model_TimeWatch.h"
#include "Model_StopWatch.h"
#include "Model_Distance.h"
#include "Model_TempHumi.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId myListenerTaskHandle;
osThreadId myControllerTasHandle;
osThreadId myPresenterTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void StartListenerTask(void const * argument);
void StartControllerTask(void const * argument);
void StartPresenterTask(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
	*ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
	*ppxIdleTaskStackBuffer = &xIdleStack[0];
	*pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
	/* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of myListenerTask */
  osThreadDef(myListenerTask, StartListenerTask, osPriorityNormal, 0, 128);
  myListenerTaskHandle = osThreadCreate(osThread(myListenerTask), NULL);

  /* definition and creation of myControllerTas */
  osThreadDef(myControllerTas, StartControllerTask, osPriorityNormal, 0, 128);
  myControllerTasHandle = osThreadCreate(osThread(myControllerTas), NULL);

  /* definition and creation of myPresenterTask */
  osThreadDef(myPresenterTask, StartPresenterTask, osPriorityNormal, 0, 128);
  myPresenterTaskHandle = osThreadCreate(osThread(myPresenterTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
	Model_ModeInit();
	Model_TimeWatchInit();
	Model_StopWatchInit();
	Model_DistanceInit();
	Model_TempHumiInit();
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_Base_Start(&htim4);
	HAL_TIM_Base_Start(&htim3);
	/* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */

	/* Infinite loop */
	for(;;)
	{
		osDelay(1);
	}
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartListenerTask */
/**
 * @brief Function implementing the myListenerTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartListenerTask */
void StartListenerTask(void const * argument)
{
  /* USER CODE BEGIN StartListenerTask */
	Listener_Init();
	/* Infinite loop */
	for(;;)
	{
		Listener_Execute();
		osDelay(1);
	}
  /* USER CODE END StartListenerTask */
}

/* USER CODE BEGIN Header_StartControllerTask */
/**
 * @brief Function implementing the myControllerTas thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartControllerTask */
void StartControllerTask(void const * argument)
{
  /* USER CODE BEGIN StartControllerTask */
	Controller_Init();
	/* Infinite loop */
	for(;;)
	{
		Controller_Execute();
		osDelay(1);
	}
  /* USER CODE END StartControllerTask */
}

/* USER CODE BEGIN Header_StartPresenterTask */
/**
 * @brief Function implementing the myPresenterTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartPresenterTask */
void StartPresenterTask(void const * argument)
{
  /* USER CODE BEGIN StartPresenterTask */
	Presenter_Init();
	/* Infinite loop */
	for(;;)
	{
		Presenter_Execute();
		osDelay(1);
	}
  /* USER CODE END StartPresenterTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
